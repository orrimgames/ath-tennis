# QP whole-body controller + MuJoCo forward sim for the swing (scene_v14 physics).
import mujoco,numpy as np,json,os,osqp,scipy.sparse as sp,time
XML='/tmp/uturn/model/scene_v14_solve.xml'
m=mujoco.MjModel.from_xml_path(XML);m.actuator_gainprm[:]=0;m.actuator_biasprm[:]=0
if os.environ.get('IMPRATIO'): m.opt.impratio=float(os.environ['IMPRATIO'])
d=mujoco.MjData(m);DT=m.opt.timestep;nv=m.nv
hinges=[k for k in range(m.njnt) if m.jnt_type[k]==3];names=[m.joint(k).name for k in hinges]
qa=np.array([m.jnt_qposadr[k] for k in hinges]);va=np.array([m.jnt_dofadr[k] for k in hinges]);nj=len(va)
lim=json.load(open('/downloads/h2_limits-18bdafd8.json'));vmx=np.array([lim[n]['velocity'] for n in names]);eff=np.array([lim[n]['effort'] for n in names])
lo=m.jnt_range[hinges,0];hi=m.jnt_range[hinges,1]
site=m.site('racket_contact').id;nb=np.array([0,-1.,0]);feet=[m.site('left_foot').id,m.site('right_foot').id]
C=np.array([-2.05,-0.25,1.13]);nt=np.array([np.cos(np.radians(2)),0,np.sin(np.radians(2))])
vt=22.0*np.array([np.cos(np.radians(17)),0,np.sin(np.radians(17))])
q0=np.load('/tmp/wbswing/q0_ready_lifted.npy')
S=np.zeros((nv,nj));S[va,np.arange(nj)]=1
def sjac(s,dd):
  jp=np.zeros((3,nv));jr=np.zeros((3,nv));mujoco.mj_jacSite(m,dd,jp,jr,s);return np.vstack([jp,jr])
def jdot_qd(s,dd,eps=1e-6):
  q=dd.qpos.copy();J0=sjac(s,dd);q1=q.copy();mujoco.mj_integratePos(m,q1,dd.qvel,eps)
  d2=mujoco.MjData(m);d2.qpos[:]=q1;mujoco.mj_kinematics(m,d2);mujoco.mj_comPos(m,d2)
  J1=sjac(s,d2);return (J1-J0)/eps@dd.qvel
def comjd(dd,eps=1e-6):
  jc0=np.zeros((3,nv));mujoco.mj_jacSubtreeCom(m,dd,jc0,1);q1=dd.qpos.copy();mujoco.mj_integratePos(m,q1,dd.qvel,eps)
  d2=mujoco.MjData(m);d2.qpos[:]=q1;mujoco.mj_kinematics(m,d2);mujoco.mj_comPos(m,d2);jc1=np.zeros((3,nv));mujoco.mj_jacSubtreeCom(m,d2,jc1,1);return (jc1-jc0)/eps@dd.qvel
def minjerk(s): s=np.clip(s,0,1);return 10*s**3-15*s**4+6*s**5,(30*s**2-60*s**3+30*s**4),(60*s-180*s**2+120*s**3)
class RefJ:
  def __init__(s,path):
    z=np.load(path);s.Q,s.V,s.A=z['Q'],z['V'],z['A']
    if 'COM' in z: s.COM,s.COMV,s.COMA=z['COM'],z['COMV'],z['COMA']
    s.T=(len(s.Q)-1)*DT;s.tb=s.T-float(os.environ.get('TAU','0.3'))
  def k(s,t): return min(int(round(t/DT)),len(s.Q)-1)
  def posture(s,t):
    k=s.k(t)
    if t>s.T+1e-9: dtt=t-s.T;return s.Q[-1][qa]+s.V[-1][va]*dtt,s.V[-1][va],0*s.A[-1][va]
    return s.Q[k][qa],s.V[k][va],s.A[k][va]
  def racket(s,t):
    k=s.k(t);d2=mujoco.MjData(m);d2.qpos[:]=s.Q[k];d2.qvel[:]=s.V[k];mujoco.mj_forward(m,d2)
    v=np.zeros(6);mujoco.mj_objectVelocity(m,d2,mujoco.mjtObj.mjOBJ_SITE,site,v,0);return d2.site_xpos[site].copy(),v[3:],np.zeros(3)
class Ref:
  def __init__(s,T,tau,qc):
    s.T,s.tau,s.qc=T,tau,qc;s.tb=T-tau;s.pb=C-vt*tau/2;s.a=vt/tau
    d.qpos[:]=q0;mujoco.mj_forward(m,d);s.p0=d.site_xpos[site].copy()
  def racket(s,t):
    if t<s.tb:
      h,hd,hdd=minjerk(t/s.tb);return s.p0+h*(s.pb-s.p0),hd/s.tb*(s.pb-s.p0),hdd/s.tb**2*(s.pb-s.p0)
    u=min(t-s.tb,s.tau);return s.pb+0.5*s.a*u**2,s.a*u,s.a
  def posture(s,t):
    h,hd,_=minjerk(t/s.T);return q0[qa]+h*(s.qc[qa]-q0[qa]),hd/s.T*(s.qc[qa]-q0[qa])
W=dict(rk=float(os.environ.get('W_RK','10')),rn=float(os.environ.get('W_RN','2')),com=float(os.environ.get('W_COM','20')),
       pel=float(os.environ.get('W_PEL','2')),feet=float(os.environ.get('W_FEET','1000')),post=float(os.environ.get('W_POST','0.1')),tau=1e-5,f=1e-7)
CPX=float(os.environ.get('CPX','0.08'));CPY=float(os.environ.get('CPY','0.025'))
def qp_step(dd,ref,t):
  mujoco.mj_forward(m,dd)
  M=np.zeros((nv,nv));mujoco.mj_fullM(m,M,dd.qM);h=dd.qfrc_bias-dd.qfrc_passive
  Jf=np.vstack([sjac(f,dd) for f in feet]);bf=np.concatenate([jdot_qd(f,dd) for f in feet])
  nx=nv+nj+12;rows=[];lb=[];ub=[]
  # dynamics
  Aeq=np.hstack([M,-S,-Jf.T]);rows.append(Aeq);lb.append(-h);ub.append(-h)
  # feet: zero accel with drift damping
  vf=Jf@dd.qvel
  # torque bounds
  rows.append(np.hstack([np.zeros((nj,nv)),np.eye(nj),np.zeros((nj,12))]));lb.append(-eff);ub.append(eff)
  # joint accel bounds: velocity + position limits
  q=dd.qpos[qa];qd=dd.qvel[va]
  H=float(os.environ.get('LOOKH','0.04'))
  pmax=2*(hi-0.005-q-qd*H)/H**2;pmin=2*(lo+0.005-q-qd*H)/H**2
  amax=np.minimum((0.95*vmx-qd)/DT,pmax);amin=np.maximum((-0.95*vmx-qd)/DT,pmin)
  bad=amin>amax;mid=np.where(bad,0.5*(amin+amax),0);amin=np.where(bad,mid-1,amin);amax=np.where(bad,mid+1,amax)
  amin=np.maximum(amin,-3000);amax=np.minimum(amax,3000);amin=np.minimum(amin,amax-1e-3)
  Ej=np.zeros((nj,nx));Ej[np.arange(nj),va]=1;rows.append(Ej);lb.append(amin);ub.append(amax)
  # contact wrench (world frame, at foot site): fz>=20, friction pyramid, CoP, torsion
  mu=0.6/np.sqrt(2)
  for i in range(2):
    o=nv+nj+6*i;G=[]
    for (a,b,c) in [(0,1,-mu),(0,-1,-mu),(1,1,-mu),(1,-1,-mu),(4,1,-CPX),(4,-1,-CPX),(3,1,-CPY),(3,-1,-CPY),(5,1,-0.03),(5,-1,-0.03)]:
      g=np.zeros(nx);g[o+a]=b;g[o+2]=c;G.append(g)
    G=np.array(G);rows.append(G);lb.append(np.full(len(G),-np.inf));ub.append(np.zeros(len(G)))
    g=np.zeros((1,nx));g[0,o+2]=1;rows.append(g);lb.append([20.]);ub.append([np.inf])
  A=sp.csc_matrix(np.vstack(rows));l=np.concatenate(lb);u=np.concatenate(ub)
  # objective: sum w||J qdd + b - a_des||^2
  P=np.zeros((nx,nx));qv=np.zeros(nx)
  def task(J,b,ades,w):
    nonlocal P,qv
    Jx=np.zeros((J.shape[0],nx));Jx[:,:nv]=J;P+=w*Jx.T@Jx;qv+=w*Jx.T@(b-ades)
  e_ft=[];
  for i,f_ in enumerate(feet):
    R=dd.site_xmat[f_].reshape(3,3);E=FEETR0[i]@R.T;er=0.5*np.array([E[2,1]-E[1,2],E[0,2]-E[2,0],E[1,0]-E[0,1]])
    e_ft.append(np.r_[FEET0[i]-dd.site_xpos[f_],er])
  task(Jf,bf,np.concatenate(e_ft)*400-40*vf,W['feet'])
  pr,vr,ar=ref.racket(t);Jr=sjac(site,dd);br=jdot_qd(site,dd);p=dd.site_xpos[site];v=Jr[:3]@dd.qvel
  wrk=W['rk'] if t>ref.T-float(os.environ.get('RKWIN','0.06')) else W['rk']*float(os.environ.get('RKEARLY','0.0'))
  task(Jr[:3],br[:3],ar+400*(pr-p)+40*(vr-v),wrk)
  R=dd.site_xmat[site].reshape(3,3);n=R@nb;w_=Jr[3:]@dd.qvel
  en=np.cross(n,nt);rn_w=W['rn']*(1 if t>ref.tb else 0.2)
  task(Jr[3:],br[3:],400*en-40*w_,rn_w)
  jc=np.zeros((3,nv));mujoco.mj_jacSubtreeCom(m,dd,jc,1);c=dd.subtree_com[1];cd=jc@dd.qvel
  if hasattr(ref,'COM'):
    jdc=comjd(dd);kk=ref.k(t);task(jc,jdc,ref.COMA[kk]+100*(ref.COM[kk]-c)+20*(ref.COMV[kk]-cd),W['com'])
  else: task(jc[:2],np.zeros(2),100*(np.array([-2.555,0.])-c[:2])-20*cd[:2],W['com'])
  Jp=np.zeros((3,nv));Jp[:,3:6]=np.eye(3)
  if hasattr(ref,'COM'):
    kk=ref.k(t);qe=np.zeros(3);mujoco.mju_subQuat(qe,ref.Q[kk][3:7],dd.qpos[3:7]);task(Jp,np.zeros(3),ref.A[kk][3:6]+100*qe+20*(ref.V[kk][3:6]-dd.qvel[3:6]),W['pel'])
  else: task(Jp,np.zeros(3),-10*dd.qvel[3:6],W['pel'])
  pq=ref.posture(t);qr,qdr=pq[0],pq[1];qddr=pq[2] if len(pq)>2 else 0*qr;Jq=np.zeros((nj,nv));Jq[np.arange(nj),va]=1
  task(Jq,np.zeros(nj),qddr+400*(qr-q)+40*(qdr-qd),W['post'])
  P[nv:nv+nj,nv:nv+nj]+=W['tau']*np.eye(nj);P[nv+nj:,nv+nj:]+=W['f']*np.eye(12)
  pr_=osqp.OSQP();pr_.setup(sp.csc_matrix(np.triu(P+1e-9*np.eye(nx))),qv,A,l,u,verbose=False,eps_abs=float(os.environ.get('EPS','1e-6')),eps_rel=float(os.environ.get('EPS','1e-6')),max_iter=40000,polish=True)
  r=pr_.solve()
  return r.x,r.info.status
def simulate(T,tau,qc,record=True):
  ref=RefJ(os.environ['REF']) if os.environ.get('REF') else Ref(T,tau,qc)
  return simulate_ref(ref)
def simulate_ref(ref):
  global FEET0,FEETR0
  T=ref.T;dd=mujoco.MjData(m);dd.qpos[:]=ref.Q[0];dd.qvel[:]=0;mujoco.mj_forward(m,dd)
  SET=float(os.environ.get('SETTLE','0'))
  if SET>0:
    A0=ref.A[0].copy();ref.A[0]=0
    if hasattr(ref,'COMA'): CA0=ref.COMA[0].copy();ref.COMA[0]=0;CV0=ref.COMV[0].copy();ref.COMV[0]=0
    for k in range(int(SET/DT)):
      x,st=qp_step(dd,ref,0.0);tq=np.clip(x[nv:nv+nj],-eff,eff);dd.qfrc_applied[:]=0;dd.qfrc_applied[va]=tq;mujoco.mj_step(m,dd)
    ref.A[0]=A0
    if hasattr(ref,'COMA'): ref.COMA[0]=CA0;ref.COMV[0]=CV0
    mujoco.mj_forward(m,dd);FEET0=[dd.site_xpos[f].copy() for f in feet];dd.time=0.0
    print('settle: ncon',dd.ncon,'base dz mm',round(1e3*(dd.qpos[2]-ref.Q[0][2]),2),'dxy mm',np.round(1e3*(dd.qpos[:2]-ref.Q[0][:2]),2),'max qvel',round(float(np.abs(dd.qvel).max()),4))
  ns=int(round((T+float(os.environ.get('TEXT','0')))/DT));log=dict(qpos=[],qvel=[],tau=[],f=[],status=[]);best=[1e9,None,None,None]
  for k in range(ns):
    x,st=qp_step(dd,ref,k*DT)
    if st!='solved' or not np.all(np.isfinite(x)):
      if k==0: break
      x=xprev
    xprev=x
    tq=np.clip(x[nv:nv+nj],-eff,eff);dd.qfrc_applied[:]=0;dd.qfrc_applied[va]=tq
    log['qpos'].append(dd.qpos.copy());log['qvel'].append(dd.qvel.copy());log['tau'].append(tq.copy());log['f'].append(x[nv+nj:].copy());log['status'].append(st)
    mujoco.mj_step(m,dd)
    mujoco.mj_forward(m,dd);pp=dd.site_xpos[site];dist=np.linalg.norm(pp-C)
    if dist<best[0]:
      vv=np.zeros(6);mujoco.mj_objectVelocity(m,dd,mujoco.mjtObj.mjOBJ_SITE,site,vv,0);best=[dist,dd.time,vv[3:].copy(),(dd.site_xmat[site].reshape(3,3)@nb).copy()]
  mujoco.mj_forward(m,dd);p=dd.site_xpos[site].copy();n=dd.site_xmat[site].reshape(3,3)@nb
  v=np.zeros(6);mujoco.mj_objectVelocity(m,dd,mujoco.mjtObj.mjOBJ_SITE,site,v,0);v=v[3:]
  log['qpos'].append(dd.qpos.copy());log['qvel'].append(dd.qvel.copy())
  fz=[min(ff[2],ff[8]) for ff in log['f']]
  out=dict(pos_err=float(np.linalg.norm(p-C)),normal_err_deg=float(np.degrees(np.arccos(np.clip(n@nt,-1,1)))),speed=float(np.linalg.norm(v)),
           vel_err=float(np.linalg.norm(v-vt)),dir_err_deg=float(np.degrees(np.arccos(np.clip(v@vt/np.linalg.norm(v)/22,-1,1)))),
           p=p.tolist(),v=v.tolist(),feet_drift=float(max(np.linalg.norm(dd.site_xpos[f]-fp) for f,fp in zip(feet,FEET0))),min_fz=float(min(fz)) if fz else None,
           closest=dict(dist=float(best[0]),t=float(best[1]),speed=float(np.linalg.norm(best[2])),dir_err_deg=float(np.degrees(np.arccos(np.clip(best[2]@vt/np.linalg.norm(best[2])/22,-1,1)))),normal_err_deg=float(np.degrees(np.arccos(np.clip(best[3]@nt,-1,1))))) if best[1] is not None else None,
           nonsolved=int(sum(1 for s in log['status'] if s not in ('solved',))))
  return out,log
d.qpos[:]=q0;mujoco.mj_forward(m,d);FEET0=[d.site_xpos[f].copy() for f in feet];FEETR0=[d.site_xmat[f].reshape(3,3).copy() for f in feet]
if __name__=='__main__':
  z=np.load(os.environ.get('CW','/tmp/wbswing/contact_wb_tau0.3.npz'));T=float(os.environ.get('T','0.8'));tau=float(os.environ.get('TAU','0.3'))
  t0=time.time();out,log=simulate(T,tau,z['q']);print('sim time',round(time.time()-t0,1),json.dumps(out))
  np.savez('/tmp/wbswing/wbc_last.npz',qpos=np.array(log['qpos']),qvel=np.array(log['qvel']),tau=np.array(log['tau']),f=np.array(log['f']))
