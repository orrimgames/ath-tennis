import numpy as np,mujoco,json,sys
m=mujoco.MjModel.from_xml_path('/tmp/uturn/model/scene_v14_solve.xml');d=mujoco.MjData(m)
r=np.load(sys.argv[1]);TH=float(sys.argv[2]) if len(sys.argv)>2 else 0.05
gs=[g for g in range(m.ngeom) if m.geom_bodyid[g]>0 and (m.geom_contype[g] or m.geom_conaffinity[g])]
def ok(a,b):
  ba,bb=m.geom_bodyid[a],m.geom_bodyid[b]
  if ba==bb or m.body_parentid[ba]==bb or m.body_parentid[bb]==ba: return False
  return (m.geom_contype[a]&m.geom_conaffinity[b]) or (m.geom_contype[b]&m.geom_conaffinity[a])
pairs=[(a,b) for i,a in enumerate(gs) for b in gs[i+1:] if ok(a,b)]
mind={p:1e9 for p in pairs};ft=np.zeros(6)
for k in range(0,len(r['Q']),4):
  d.qpos[:]=r['Q'][k];mujoco.mj_kinematics(m,d)
  for p in pairs:
    dist=mujoco.mj_geomDistance(m,d,p[0],p[1],0.2,ft)
    mind[p]=min(mind[p],dist)
close=sorted([(v,m.geom(a).name,m.geom(b).name) for (a,b),v in mind.items() if v<TH])
print(len(pairs),'pairs;',len(close),'close');[print(round(v,3),a,b) for v,a,b in close]
json.dump([[a,b] for v,a,b in close],open('/tmp/wbswing/coll_pairs.json','w'))
