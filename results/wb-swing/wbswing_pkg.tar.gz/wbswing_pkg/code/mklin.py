import os,sys,numpy as np,casadi as ca
os.environ['COLL']=os.environ.get('COLLSET','/tmp/wbswing/coll_keep2.json');import nlp as P
z=np.load(sys.argv[1]);Q=z['Q'];N=Q.shape[1]
q=ca.SX.sym('q',P.NQ);Jf=ca.Function('J',[q],[ca.jacobian(P.COLLF(q),q)])
G=np.array([np.array(P.COLLF(Q[:,k])).flatten() for k in range(N)]).T;J=np.array([np.array(Jf(Q[:,k])) for k in range(N)])
np.savez(sys.argv[2],G=G,J=J,Q=Q);print('min g',G.min().round(4),'active',(G<0.06).sum(),'viol',(G<0).sum())
