import numpy as np,casadi as ca,sys,mujoco
import nlp as P, cmodel as M
S=sys.argv[1];OUT=sys.argv[2];DT=0.002
z=np.load(S);Qs,Vs,As=z['Q'],z['V'],z['A'];T=float(z['T']);No=Qs.shape[1];ho=T/(No-1)
e=ca.SX.sym('e',3);Rf=ca.Function('R',[e],[M.Rzyx(e)]);Ef=ca.Function('E',[e],[M.Emat(e)])
def path(t):
  k=min(int(t/ho+1e-9),No-1)
  if k==No-1: s=t-T;return Qs[:,k]+Vs[:,k]*s,Vs[:,k].copy(),As[:,k].copy()
  s=t-k*ho;return Qs[:,k]+Vs[:,k]*s+0.5*As[:,k]*s*s,Vs[:,k]+As[:,k]*s,As[:,k]
ts=np.arange(0,T+1e-9,DT);QQ=[];VV=[];AA=[];CM=[]
for t in ts:
  g,v,a=path(t);qp=P.gen_to_mj(g);R=np.array(Rf(g[3:6]));E=np.array(Ef(g[3:6]))
  qv=np.zeros(M.m.nv);qv[:3]=v[:3];qv[3:6]=R.T@(E@v[3:6]);qa=np.zeros(M.m.nv)
  for i,b in enumerate(M.hinge_b): qv[M.B[b]['dof']]=v[6+i];qa[M.B[b]['dof']]=a[6+i]
  QQ.append(qp);VV.append(qv);AA.append(qa);CM.append(np.array(P.CM(g)).flatten())
CM=np.array(CM);CMV=np.gradient(CM,DT,axis=0);CMA=np.gradient(CMV,DT,axis=0);VV=np.array(VV);AA=np.array(AA);AA[:,:6]=np.gradient(VV[:,:6],DT,axis=0)
np.savez(OUT,Q=np.array(QQ),V=np.array(VV),A=np.array(AA),COM=CM,COMV=CMV,COMA=CMA,t=ts)
print('ref',len(ts),'com0',CM[0].round(3),'comT',CM[-1].round(3))
