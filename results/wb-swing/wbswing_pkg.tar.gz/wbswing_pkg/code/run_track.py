import os,sys,json,time,numpy as np
import wbc
ref=wbc.RefJ(sys.argv[1]);t0=time.time();out,log=wbc.simulate_ref(ref)
print('t',round(time.time()-t0,1),json.dumps(out))
np.savez(sys.argv[2],qpos=np.array(log['qpos']),qvel=np.array(log['qvel']),tau=np.array(log['tau']),f=np.array(log['f']))
