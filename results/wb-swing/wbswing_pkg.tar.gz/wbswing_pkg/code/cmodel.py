# Symbolic rigid-body model (CasADi) extracted from the MuJoCo scene; validated against MuJoCo as oracle.
import casadi as ca,numpy as np,mujoco
XML='/tmp/uturn/model/scene_v14_solve.xml'
m=mujoco.MjModel.from_xml_path(XML)
def qmat(q):
  w,x,y,z=q;return np.array([[1-2*(y*y+z*z),2*(x*y-w*z),2*(x*z+w*y)],[2*(x*y+w*z),1-2*(x*x+z*z),2*(y*z-w*x)],[2*(x*z-w*y),2*(y*z+w*x),1-2*(x*x+y*y)]])
# ---- tree extraction: merge welded bodies into nearest jointed ancestor ----
jointed={};order=[]
for b in range(1,m.nbody):
  if m.body_jntnum[b]==1: order.append(b)
def anc_joint(b):
  R=np.eye(3);p=np.zeros(3);a=b
  while m.body_jntnum[a]==0:
    Ra=qmat(m.body_quat[a]);p=Ra@p+m.body_pos[a];R=Ra@R;a=m.body_parentid[a]
  return a,R,p   # pose of body b in frame of jointed ancestor a
B={}
for b in order:
  par=m.body_parentid[b];a,Rw,pw=(par,np.eye(3),np.zeros(3)) if (par==0 or m.body_jntnum[par]==1) else anc_joint(par)
  # b's frame relative to a: (Rw,pw) of parent in a, then b's own pos/quat
  Rrel=Rw@qmat(m.body_quat[b]);prel=Rw@m.body_pos[b]+pw
  j=m.body_jntadr[b];B[b]=dict(parent=a,R=Rrel,p=prel,type=m.jnt_type[j],axis=m.jnt_axis[j].copy(),jid=j,dof=m.jnt_dofadr[j],qadr=m.jnt_qposadr[j],
    mass=0.,com=np.zeros(3),I=np.zeros((3,3)),children=[])
def add_inertia(Bb,mass,com,I):   # com,I in Bb frame (I about com)
  M0=Bb['mass'];c0=Bb['com'];Mt=M0+mass
  if Mt<=0: return
  ct=(M0*c0+mass*com)/Mt
  def sh(I_,mm,c,cn): d=c-cn;return I_+mm*(np.dot(d,d)*np.eye(3)-np.outer(d,d))
  Bb['I']=sh(Bb['I'],M0,c0,ct)+sh(I,mass,com,ct);Bb['com']=ct;Bb['mass']=Mt
for b in range(1,m.nbody):
  if m.body_mass[b]==0: continue
  if m.body_jntnum[b]==1: a,R,p=b,np.eye(3),np.zeros(3)
  else: a,R,p=anc_joint(b)
  Ri=qmat(m.body_iquat[b]);I=R@Ri@np.diag(m.body_inertia[b])@Ri.T@R.T;com=R@m.body_ipos[b]+p
  add_inertia(B[a],m.body_mass[b],com,I)
for b in order:
  if B[b]['parent']!=0: B[B[b]['parent']]['children'].append(b)
def site_in(sname):
  s=m.site(sname).id;b=m.site_bodyid[s]
  if m.body_jntnum[b]==1: a,R,p=b,np.eye(3),np.zeros(3)
  else: a,R,p=anc_joint(b)
  return a,R@qmat(m.site_quat[s]),R@m.site_pos[s]+p
SITES={n:site_in(n) for n in ['racket_contact','left_foot','right_foot']}
root=order[0];assert B[root]['type']==0
hinge_b=[b for b in order if B[b]['type']==3]
NJ=len(hinge_b);NQ=6+NJ   # generalized coords: [px,py,pz,yaw,pitch,roll, joints...]
arm=np.array([m.dof_armature[B[b]['dof']] for b in hinge_b]);damp=np.array([m.dof_damping[B[b]['dof']] for b in hinge_b])
def rot_axis(ax,th):
  ax=np.asarray(ax,float);K=ca.SX(np.array([[0,-ax[2],ax[1]],[ax[2],0,-ax[0]],[-ax[1],ax[0],0]]))
  return ca.SX.eye(3)+ca.sin(th)*K+(1-ca.cos(th))*(K@K)
def Rzyx(e):
  y,p,r=e[0],e[1],e[2]
  Rz=ca.vertcat(ca.horzcat(ca.cos(y),-ca.sin(y),0),ca.horzcat(ca.sin(y),ca.cos(y),0),ca.horzcat(0,0,1))
  Ry=ca.vertcat(ca.horzcat(ca.cos(p),0,ca.sin(p)),ca.horzcat(0,1,0),ca.horzcat(-ca.sin(p),0,ca.cos(p)))
  Rx=ca.vertcat(ca.horzcat(1,0,0),ca.horzcat(0,ca.cos(r),-ca.sin(r)),ca.horzcat(0,ca.sin(r),ca.cos(r)))
  return Rz@Ry@Rx
def Emat(e):  # world angular velocity = E(e) * edot  for ZYX
  y,p=e[0],e[1]
  return ca.horzcat(ca.vertcat(0,0,1),ca.vertcat(-ca.sin(y),ca.cos(y),0),ca.vertcat(ca.cos(y)*ca.cos(p),ca.sin(y)*ca.cos(p),-ca.sin(p)))
def fk(q):
  """world pose of every jointed body"""
  P={};R={}
  R[root]=Rzyx(q[3:6]);P[root]=q[0:3]
  for i,b in enumerate(hinge_b):
    a=B[b]['parent'];Rl=ca.SX(B[b]['R'])@rot_axis(B[b]['axis'],q[6+i])
    R[b]=R[a]@Rl;P[b]=P[a]+R[a]@ca.SX(B[b]['p'])
  return P,R
def site_pose(q,name):
  P,R=fk(q);a,Rs,ps=SITES[name];return P[a]+R[a]@ca.SX(ps),R[a]@ca.SX(Rs)
def com(q):
  P,R=fk(q);Mt=0;c=0
  for b in order: c=c+B[b]['mass']*(P[b]+R[b]@ca.SX(B[b]['com']));Mt+=B[b]['mass']
  return c/Mt
def rnea(q,v,a,fext=None):
  """returns (tau_joints[NJ], base wrench world-force(3), world-moment about pelvis origin(3)); fext: dict body->(f_world, point_world)"""
  e=q[3:6];ed=v[3:6];edd=a[3:6];Rb=Rzyx(e);E=Emat(e)
  ww=E@ed;Ed=ca.jtimes(E,e,ed);wdw=E@edd+Ed@ed
  W={};Wd={};A={}
  W[root]=Rb.T@ww;Wd[root]=Rb.T@wdw;A[root]=Rb.T@(a[0:3]+ca.SX([0,0,9.81]))
  for i,b in enumerate(hinge_b):
    p=B[b]['parent'];Rl=ca.SX(B[b]['R'])@rot_axis(B[b]['axis'],q[6+i]);r=ca.SX(B[b]['p']);ax=ca.SX(B[b]['axis'])
    wp=W[p];wdp=Wd[p]
    A[b]=Rl.T@(A[p]+ca.cross(wdp,r)+ca.cross(wp,ca.cross(wp,r)))
    wl=Rl.T@wp;W[b]=wl+ax*v[6+i];Wd[b]=Rl.T@wdp+ca.cross(wl,ax*v[6+i])+ax*a[6+i]
  F={};N={}
  P,Rw=fk(q) if fext else (None,None)
  for b in reversed(order):
    c=ca.SX(B[b]['com']);Ic=ca.SX(B[b]['I']);mm=B[b]['mass']
    ac=A[b]+ca.cross(Wd[b],c)+ca.cross(W[b],ca.cross(W[b],c))
    f=mm*ac;n=Ic@Wd[b]+ca.cross(W[b],Ic@W[b])+ca.cross(c,mm*ac)
    for ch in B[b]['children']:
      Rl=ca.SX(B[ch]['R'])@rot_axis(B[ch]['axis'],q[6+hinge_b.index(ch)]);r=ca.SX(B[ch]['p'])
      fc=Rl@F[ch];f=f+fc;n=n+Rl@N[ch]+ca.cross(r,fc)
    if fext and b in fext:
      fw,pw=fext[b][0],fext[b][1];mw=fext[b][2] if len(fext[b])>2 else ca.SX.zeros(3)
      fb=Rw[b].T@fw;nb=Rw[b].T@(ca.cross(pw-P[b],fw)+mw);f=f-fb;n=n-nb
    F[b]=f;N[b]=n
  tau=ca.vertcat(*[ca.dot(ca.SX(B[b]['axis']),N[b]) for b in hinge_b])+ca.SX(arm)*a[6:]+ca.SX(damp)*v[6:]
  return tau,Rb@F[root],Rb@N[root]
def geom_samples(gname):
  g=m.geom(gname).id;b=m.geom_bodyid[g]
  if m.body_jntnum[b]==1: a,R,p=b,np.eye(3),np.zeros(3)
  else: a,R,p=anc_joint(b)
  Rg=R@qmat(m.geom_quat[g]);pg=R@m.geom_pos[g]+p;r=m.geom_size[g][0]
  if m.geom_type[g]==3:
    hl=m.geom_size[g][1];n=int(np.ceil(2*hl/r))+1;pts=[pg+Rg@np.array([0,0,s]) for s in np.linspace(-hl,hl,n)]
  else: pts=[pg]
  return a,pts,r
def geom_points(q,gname):
  P,R=fk(q);a,pts,r=geom_samples(gname);return [P[a]+R[a]@ca.SX(pp) for pp in pts],r
def geom_points_fk(PR,gname):
  P,R=PR;a,pts,r=geom_samples(gname);return [P[a]+R[a]@ca.SX(pp) for pp in pts],r
