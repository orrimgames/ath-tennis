import numpy as np,mujoco,imageio.v2 as imageio,os,sys
z=np.load(sys.argv[1]);OUT=sys.argv[2];Q=z['qpos'];B=z['ball_qpos'];t=z['t']
m=mujoco.MjModel.from_xml_path('/tmp/uturn/model/scene_v14.xml');d=mujoco.MjData(m)
bq=m.jnt_qposadr[m.joint('feed_ball_joint').id];ren=mujoco.Renderer(m,height=480,width=848)
def frame(tt,cam):
  k=int(np.clip(np.searchsorted(t,tt),0,len(t)-1));d.qpos[:]=0;d.qpos[:Q.shape[1]]=Q[k];d.qpos[bq:bq+7]=B[k];mujoco.mj_forward(m,d)
  c=mujoco.MjvCamera();c.azimuth,c.elevation,c.distance=cam;c.lookat[:]=[-2.3,0,0.95];ren.update_scene(d,c);return ren.render()
w=imageio.get_writer(OUT,fps=60,codec='libx264',quality=7,macro_block_size=16)
cam=(100,-8,3.0);T=t[-1]
for i in range(int(T*60)+1): w.append_data(frame(i/60,cam))
for i in range(int(0.14*60*8)): w.append_data(frame(0.70+i/(60*8),cam))
for i in range(int(0.14*60*8)): w.append_data(frame(0.70+i/(60*8),(160,-10,2.4)))
w.close();print('ok')
