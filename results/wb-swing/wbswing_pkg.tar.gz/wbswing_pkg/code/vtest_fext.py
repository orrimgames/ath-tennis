exec(open('validate_cmodel.py').read().split("emax=dict")[0])
lb_=M.SITES['left_foot'][0]
fw=ca.SX.sym('fw',3);nw=ca.SX.sym('nw',3)
lp,_=M.site_pose(q,'left_foot')
P,Rw=M.fk(q)
# external wrench at foot site: force fw at point lp plus pure moment nw -> encode moment as force couple not supported; extend rnea: use two calls
tau_f,fb_f,nb_f=M.rnea(q,v,a,fext={lb_:(fw,lp)})
Fx=ca.Function('x',[q,v,a,fw],[tau_f,fb_f,nb_f])
worst=0
for t in range(10):
  qq=np.r_[rng.normal(0,0.5,3),rng.normal(0,0.4,3),rng.normal(0,0.5,M.NJ)];vv=rng.normal(0,2,M.NQ);aa=rng.normal(0,5,M.NQ);f=rng.normal(0,300,3)
  R=to_mj(qq,vv,aa);qs=d.qacc.copy();mujoco.mj_forward(m,d);d.qacc[:]=qs;mujoco.mj_inverse(m,d);qi=d.qfrc_inverse.copy()
  qf=np.zeros(m.nv);mujoco.mj_applyFT(m,d,f,np.zeros(3),d.site('left_foot').xpos,m.site_bodyid[m.site('left_foot').id],qf)
  need=qi-qf   # generalized force still needed from actuators/base when foot wrench acts
  tt,ff,nn=[np.array(x).flatten() for x in Fx(qq,vv,aa,f)];tj=np.array([need[M.B[b]['dof']] for b in M.hinge_b])
  worst=max(worst,np.abs(tt-tj).max(),np.abs(ff-need[:3]).max(),np.abs(R.T@nn-need[3:6]).max())
print('fext worst abs err',worst)
