# Closed-loop whole-body swing in scene_v14 (with ball) at dt=2.5e-4; WBC QP at 2 ms (zero-order hold); stationary ball at C.
import os,sys,json,numpy as np,mujoco
import wbc
REF=sys.argv[1];OUT=sys.argv[2];ROLL=float(os.environ.get('ROLL','0.001'))
mB=mujoco.MjModel.from_xml_path('/tmp/uturn/model/scene_v14.xml');mB.opt.timestep=float(os.environ.get('SIMDT','2.5e-4'))
mB.actuator_gainprm[:]=0;mB.actuator_biasprm[:]=0
bg=mB.geom('feed_ball_geom').id;rg=mB.geom('tennis_racket_collision').id
mB.geom_friction[bg,2]=ROLL;mB.geom_friction[rg,2]=ROLL
dB=mujoco.MjData(mB);ref=wbc.RefJ(REF);m=wbc.m;dd=mujoco.MjData(m)
nq,nv=m.nq,m.nv;bq=mB.jnt_qposadr[mB.joint('feed_ball_joint').id];bv=mB.jnt_dofadr[mB.joint('feed_ball_joint').id]
nt=wbc.nt;BALL=wbc.C+(0.033+0.005)*nt
dB.qpos[:nq]=ref.Q[0];dB.qpos[bq:bq+3]=[0,0,-2];dB.qpos[bq+3]=1
# settle using the solve-model WBC
SET=float(os.environ.get('SETTLE','0.3'))
os.environ['TEXT']=os.environ.get('TEXT','0.04')
dd.qpos[:]=ref.Q[0];mujoco.mj_forward(m,dd)
A0=ref.A[0].copy();ref.A[0]=0;CA0=ref.COMA[0].copy();ref.COMA[0]=0;CV0=ref.COMV[0].copy();ref.COMV[0]=0
QDT=float(os.environ.get('QPDT',wbc.DT));sub=int(round(QDT/mB.opt.timestep))
def ctrl(t):
  dd.qpos[:]=dB.qpos[:nq];dd.qvel[:]=dB.qvel[:nv];x,st=wbc.qp_step(dd,ref,t);return np.clip(x[nv:nv+wbc.nj],-wbc.eff,wbc.eff),st
for k in range(int(SET/QDT)):
  tq,_=ctrl(0.0);dB.qfrc_applied[:]=0;dB.qfrc_applied[wbc.va]=tq
  for _ in range(sub): mujoco.mj_step(mB,dB)
ref.A[0]=A0;ref.COMA[0]=CA0;ref.COMV[0]=CV0
mujoco.mj_forward(mB,dB);wbc.FEET0=[dB.site_xpos[mB.site(n).id].copy() for n in ('left_foot','right_foot')]
#wbc.FEETR0=[dB.site_xmat[mB.site(n).id].reshape(3,3).copy() for n in ('left_foot','right_foot')]
lf0=[x.copy() for x in wbc.FEET0]
T=ref.T;TEND=T+float(os.environ['TEXT']);t=0.0;held=True;c0=c1=None;taulog=[];qlog=[];nonsolved=0;racket_at_c=None
blog=[];tlog=[];ball_ctr_hold=BALL.copy() if not os.environ.get('BALLOFF') else np.array([0,0,-2.]);k=0;atT=None
while t<TEND-1e-12:
  tq,st=ctrl(t);nonsolved+=st!='solved';taulog.append(tq);qlog.append(dB.qpos[:nq].copy());blog.append(dB.qpos[bq:bq+7].copy());tlog.append(t)
  dB.qfrc_applied[:]=0;dB.qfrc_applied[wbc.va]=tq
  for _ in range(sub):
    if held: dB.qpos[bq:bq+3]=ball_ctr_hold;dB.qpos[bq+3:bq+7]=[1,0,0,0];dB.qvel[bv:bv+6]=0
    mujoco.mj_step(mB,dB)
    touch=any((dB.contact[i].geom1,dB.contact[i].geom2) in ((bg,rg),(rg,bg)) for i in range(dB.ncon))
    if touch and c0 is None:
      c0=dB.time;held=False;v6=np.zeros(6);mujoco.mj_objectVelocity(mB,dB,mujoco.mjtObj.mjOBJ_SITE,mB.site('racket_contact').id,v6,0)
      racket_at_c=dict(t=float(dB.time),site=dB.site('racket_contact').xpos.tolist(),vel=v6[3:].tolist(),speed=float(np.linalg.norm(v6[3:])),normal=(dB.site('racket_contact').xmat.reshape(3,3)@np.array([0,-1.,0])).tolist())
    if c0 is not None and c1 is None and not touch and dB.time-c0>1e-4: c1=dB.time;vb=dB.qvel[bv:bv+3].copy();wb=dB.qvel[bv+3:bv+6].copy()
  t+=QDT;k+=1
  if abs(t-T)<1e-9: atT=dict(site=dB.site('racket_contact').xpos.tolist(),normal=(dB.site('racket_contact').xmat.reshape(3,3)@np.array([0,-1.,0])).tolist())
res=dict(atT=atT,roll=ROLL,dt=mB.opt.timestep,contact_start=c0,contact_end=c1,dwell_ms=(c1-c0)*1e3 if c1 else None,racket_at_contact=racket_at_c,nonsolved=int(nonsolved),
 feet_drift_mm=[1e3*float(np.linalg.norm(dB.site_xpos[mB.site(n).id]-p)) for n,p in zip(('left_foot','right_foot'),lf0)])
if c1:
  res.update(exit_speed=float(np.linalg.norm(vb)),exit_vel=vb.tolist(),spin_rad_s=float(np.linalg.norm(wb)),spin_axis_body=(wb/np.linalg.norm(wb)).tolist(),
   exit_elev_deg=float(np.degrees(np.arctan2(vb[2],np.hypot(vb[0],vb[1])))),exit_azim_deg=float(np.degrees(np.arctan2(vb[1],vb[0]))))
TA=np.array(taulog);TL=np.array(tlog);pre=TL<=((c0-SET) if c0 else T)
def tab(M):
  pk=np.abs(M).max(0);return [dict(joint=n,peak_Nm=round(float(pk[i]),2),limit_Nm=float(wbc.eff[i]),pct=round(100*float(pk[i]/wbc.eff[i]),1),sat_steps=int((np.abs(M[:,i])>=wbc.eff[i]*0.999).sum())) for i,n in enumerate(wbc.names)]
res['torque_table_swing']=tab(TA[pre]);res['torque_table_after_contact']=tab(TA[~pre]) if (~pre).any() else None
peak=np.abs(TA).max(0)
res['torque_table']=[dict(joint=n,peak_Nm=round(float(peak[i]),2),limit_Nm=float(wbc.eff[i]),pct=round(100*float(peak[i]/wbc.eff[i]),1),sat_steps=int((np.abs(TA[:,i])>=wbc.eff[i]*0.999).sum())) for i,n in enumerate(wbc.names)]
np.savez(OUT,t=TL,qpos=np.array(qlog),ball_qpos=np.array(blog),tau=TA,qp_dt=QDT,settle_s=SET)
json.dump(res,open(OUT.replace('.npz','.json'),'w'),indent=1)
print(json.dumps({k:v for k,v in res.items() if not k.startswith('torque_table')}))
