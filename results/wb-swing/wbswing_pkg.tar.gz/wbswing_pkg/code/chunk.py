import numpy as np,os,sys,time,casadi as ca
import nlp as P
N=int(os.environ.get('N','21'));T=float(os.environ.get('T','0.8'));TAG=os.environ.get('TAG',f'N{N}T{T}')
st=f'/tmp/wbswing/chunk_{TAG}.npz'
def from_sol(path,N,T):
  z=np.load(path);Qs,Vs,As,Fl,Fr=z['Q'],z['V'],z['A'],z['FL'],z['FR'];No=Qs.shape[1];to=np.linspace(0,T,No);tn=np.linspace(0,T,N)
  # exact evaluation of piecewise-constant-accel path
  ho=T/(No-1);Q=np.zeros((Qs.shape[0],N));V=np.zeros_like(Q);A=np.zeros_like(Q)
  for i,t in enumerate(tn):
    k=min(int(t/ho),No-2);s=t-k*ho;Q[:,i]=Qs[:,k]+Vs[:,k]*s+0.5*As[:,k]*s*s;V[:,i]=Vs[:,k]+As[:,k]*s;A[:,i]=As[:,k]
  it=lambda X:np.array([np.interp(tn,to,x) for x in X])
  return Q,V,A,it(Fl),it(Fr)
g=from_sol(os.environ['GUESS'],N,T) if os.environ.get('GUESS') else P.guess_from_ref('/tmp/wbswing/ref_tau0.300.npz',N,T)
op,X=P.build(N,T,g)
opts={'max_cpu_time':float(os.environ.get('CPU','90')),'print_level':0,'tol':1e-6,'acceptable_tol':1e-4,'linear_solver':'mumps','max_iter':3000}
if os.environ.get('LBFGS'): opts['hessian_approximation']='limited-memory'
if os.path.exists(st):
  z=np.load(st);op.set_initial(op.x,z['x']);op.set_initial(op.lam_g,z['lam']);opts.update({'warm_start_init_point':'yes','warm_start_bound_push':1e-6,'warm_start_mult_bound_push':1e-6,'mu_init':float(os.environ.get('MUI',z['mu'] if 'mu' in z else 1e-3))})
  if os.environ.get('MONO'): opts['mu_strategy']='monotone'
op.solver('ipopt',{'expand':False,'print_time':False},opts)
t=time.time()
try: sol=op.solve();ok=True
except Exception: sol=op.debug;ok=False
stats=sol.stats();x=np.array(sol.value(op.x)).flatten();lam=np.array(sol.value(op.lam_g)).flatten()
prev_it=int(np.load(st)['iters']) if os.path.exists(st) else 0
np.savez(st,x=x,lam=lam,iters=prev_it+stats['iter_count'],mu=1e-4)
Qv=np.array(sol.value(X[0]));Vv=np.array(sol.value(X[1]))
np.savez(f'/tmp/wbswing/sol_{TAG}.npz',Q=Qv,V=Vv,A=np.array(sol.value(X[2])),FL=np.array(sol.value(X[3])),FR=np.array(sol.value(X[4])),T=T,N=N,ok=ok)
p,n,vs=[np.array(v).flatten() for v in P.RK(Qv[:,-1],Vv[:,-1])]
print('ok',ok,stats['return_status'],'iters',stats['iter_count'],'total',prev_it+stats['iter_count'],'time',round(time.time()-t,1),'obj',float(sol.value(op.f)),
      'inf_pr',stats['iterations']['inf_pr'][-1] if stats.get('iterations') else None,'|v_rk|',np.linalg.norm(vs).round(2),'pos err',np.linalg.norm(p-P.C).round(4))
