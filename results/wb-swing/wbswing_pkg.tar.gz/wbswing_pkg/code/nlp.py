import casadi as ca,numpy as np,json,os,time,mujoco
import cmodel as M
m=M.m;NQ=M.NQ;NJ=M.NJ
lim=json.load(open('/downloads/h2_limits-18bdafd8.json'))
jn=[m.joint(M.B[b]['jid']).name for b in M.hinge_b]
eff=np.array([lim[n]['effort'] for n in jn]);vmx=np.array([lim[n]['velocity'] for n in jn])
lo=m.jnt_range[[M.B[b]['jid'] for b in M.hinge_b],0];hi=m.jnt_range[[M.B[b]['jid'] for b in M.hinge_b],1]
C=np.array([-2.05,-0.25,1.13]);nt=np.array([np.cos(np.radians(2)),0,np.sin(np.radians(2))]);vt=22.0*np.array([np.cos(np.radians(17)),0,np.sin(np.radians(17))])
nbv=np.array([0,-1.,0])
q=ca.SX.sym('q',NQ);v=ca.SX.sym('v',NQ);a=ca.SX.sym('a',NQ);fl=ca.SX.sym('fl',6);fr=ca.SX.sym('fr',6)
lfb=M.SITES['left_foot'][0];rfb=M.SITES['right_foot'][0]
lp,lR=M.site_pose(q,'left_foot');rp,rR=M.site_pose(q,'right_foot')
tau,fb,nb=M.rnea(q,v,a,fext={lfb:(fl[:3],lp,fl[3:]),rfb:(fr[:3],rp,fr[3:])})
ID=ca.Function('ID',[q,v,a,fl,fr],[tau,fb,nb])
FEET=ca.Function('FEET',[q],[lp,ca.reshape(lR,9,1),rp,ca.reshape(rR,9,1)])
sp,sR=M.site_pose(q,'racket_contact');sv=ca.jtimes(sp,q,v)
RK=ca.Function('RK',[q,v],[sp,sR@ca.SX(nbv),sv])
CM=ca.Function('CM',[q],[M.com(q)])
COLL=[]
if os.environ.get('COLL'):
  _d=[];_PR=M.fk(q)
  for g1,g2 in json.load(open(os.environ['COLL'])):
    p1,r1=M.geom_points_fk(_PR,g1);p2,r2=M.geom_points_fk(_PR,g2)
    xs=ca.vertcat(*[ca.sqrt(ca.sumsqr(a_-b_)+1e-8)-(r1+r2+float(os.environ.get('COLLMARGIN','0.01'))) for a_ in p1 for b_ in p2])
    _d.append(-ca.log(ca.sum1(ca.exp(-200*xs)))/200)
  COLLF=ca.Function('COLLF',[q],[ca.vertcat(*_d)]);COLL=[1]
def mj_to_gen(qpos):
  R=np.zeros(9);mujoco.mju_quat2Mat(R,qpos[3:7]);R=R.reshape(3,3)
  pitch=-np.arcsin(np.clip(R[2,0],-1,1));yaw=np.arctan2(R[1,0],R[0,0]);roll=np.arctan2(R[2,1],R[2,2])
  g=np.zeros(NQ);g[:3]=qpos[:3];g[3:6]=[yaw,pitch,roll]
  for i,b in enumerate(M.hinge_b): g[6+i]=qpos[M.B[b]['qadr']]
  return g
def gen_to_mj(g):
  qp=np.zeros(m.nq);qp[:3]=g[:3];y,p,r=g[3:6]
  Rz=np.array([[np.cos(y),-np.sin(y),0],[np.sin(y),np.cos(y),0],[0,0,1]]);Ry=np.array([[np.cos(p),0,np.sin(p)],[0,1,0],[-np.sin(p),0,np.cos(p)]]);Rx=np.array([[1,0,0],[0,np.cos(r),-np.sin(r)],[0,np.sin(r),np.cos(r)]])
  qt=np.zeros(4);mujoco.mju_mat2Quat(qt,(Rz@Ry@Rx).flatten());qp[3:7]=qt
  for i,b in enumerate(M.hinge_b): qp[M.B[b]['qadr']]=g[6+i]
  return qp
LIN=None
def load_lin(path,N):
  global LIN
  z=np.load(path);G,Jc,Q0=z['G'],z['J'],z['Q'];LIN={}
  for k in range(N):
    for i in range(G.shape[0]):
      if G[i,k]<float(os.environ.get('LINTH','0.06')): LIN.setdefault(k,[]).append((i,float(G[i,k]),Jc[k,i],Q0[:,k]))
TM_=np.array([float(os.environ.get('TAUMARGIN_WRIST' if 'wrist' in n else 'TAUMARGIN','1.0')) if ('wrist' in n or True) else 1 for n in jn])
CPX_=float(os.environ.get('CPX','0.08'));CPY_=float(os.environ.get('CPY','0.025'))
def build(N,T,guess=None):
  if os.environ.get('COLLLIN'): load_lin(os.environ['COLLLIN'],N)
  h=T/(N-1);op=ca.Opti()
  Q=op.variable(NQ,N);V=op.variable(NQ,N);A=op.variable(NQ,N);FL=op.variable(6,N);FR=op.variable(6,N)
  MID=int(os.environ.get('MID','0'));FLm=op.variable(6,N-1) if MID else None;FRm=op.variable(6,N-1) if MID else None
  q0=mj_to_gen(np.load('/tmp/wbswing/q0_ready_lifted.npy'))
  f0=FEET(q0);lp0,lR0,rp0,rR0=[np.array(x).flatten() for x in f0]
  op.subject_to(Q[:,0]==q0);op.subject_to(V[:,0]==0)
  J=0
  for k in range(N):
    if k<N-1:
      op.subject_to(Q[:,k+1]==Q[:,k]+h*V[:,k]+0.5*h**2*A[:,k]);op.subject_to(V[:,k+1]==V[:,k]+h*A[:,k])
    tq,fbk,nbk=ID(Q[:,k],V[:,k],A[:,k],FL[:,k],FR[:,k])
    op.subject_to(fbk==0);op.subject_to(nbk==0)
    op.subject_to(op.bounded(-TM_*eff,tq,TM_*eff))
    op.subject_to(op.bounded(-0.95*vmx,V[6:,k],0.95*vmx))
    op.subject_to(op.bounded(lo+0.005,Q[6:,k],hi-0.005))
    if LIN is not None:
      for (kk_,g0_,J_,q0_) in LIN.get(k,[]): op.subject_to(g0_+ca.DM(J_).T@(Q[:,k]-ca.DM(q0_))>=0)
    if COLL and (k%int(os.environ.get('COLLSTRIDE','1'))==0 or k==N-1): op.subject_to(COLLF(Q[:,k])>=0)
    lp,lR,rp,rR=FEET(Q[:,k])
    op.subject_to(lp==lp0);op.subject_to(rp==rp0)
    for R,R0 in [(lR,lR0),(rR,rR0)]:
      Rm=ca.reshape(R,3,3);R0m=ca.DM(R0.reshape(3,3,order='F'));E_=R0m.T@Rm-Rm.T@R0m
      op.subject_to(ca.vertcat(E_[2,1],E_[0,2],E_[1,0])==0)
    pts=[(F,k) for F in (FL,FR)]
    if MID and k<N-1:
      for sm in (0.5,):
        qm=Q[:,k]+sm*h*V[:,k]+0.5*(sm*h)**2*A[:,k];vm=V[:,k]+sm*h*A[:,k]
        tm,fbm,nbm=ID(qm,vm,A[:,k],FLm[:,k],FRm[:,k]);op.subject_to(fbm==0);op.subject_to(nbm==0);op.subject_to(op.bounded(-TM_*eff,tm,TM_*eff))
        J=J+0.0*h*ca.sumsqr(tm/eff)
      pts+=[(FLm,k),(FRm,k)]
    for F,kk in pts:
      fz=F[2,kk];mu=0.42
      op.subject_to(fz>=20);op.subject_to(op.bounded(-mu*fz,F[0,kk],mu*fz));op.subject_to(op.bounded(-mu*fz,F[1,kk],mu*fz))
      op.subject_to(op.bounded(-CPY_*fz,F[3,kk],CPY_*fz));op.subject_to(op.bounded(-CPX_*fz,F[4,kk],CPX_*fz));op.subject_to(op.bounded(-0.03*fz,F[5,kk],0.03*fz))
    J=J+h*ca.sumsqr(tq/eff)+1e-4*h*ca.sumsqr(A[:,k])
  TF_=float(os.environ.get('FOLLOW','0'))
  if TF_>0: op.subject_to(op.bounded(lo+0.005,Q[6:,-1]+TF_*V[6:,-1],hi-0.005))
  p,n,vs=RK(Q[:,-1],V[:,-1])
  op.subject_to(p==C);op.subject_to(vs==vt);op.subject_to(ca.cross(n,ca.DM(nt))==0);op.subject_to(ca.dot(n,ca.DM(nt))>=0.9)
  op.minimize(J)
  if guess is not None:
    for X,G in zip([Q,V,A,FL,FR],guess): op.set_initial(X,G)
    if MID:
      op.set_initial(FLm,0.5*(guess[3][:,:-1]+guess[3][:,1:]));op.set_initial(FRm,0.5*(guess[4][:,:-1]+guess[4][:,1:]))
  op.solver('ipopt',{'expand':True},{'max_iter':int(os.environ.get('MAXIT','500')),'print_level':5,'tol':1e-6,'acceptable_tol':1e-4,'mu_strategy':'adaptive','linear_solver':'mumps'})
  return op,(Q,V,A,FL,FR)+((FLm,FRm) if MID else ())
def guess_from_ref(path,N,T):
  z=np.load(path);Qm=z['Q'];n=len(Qm);idx=np.linspace(0,n-1,N).round().astype(int)
  G=np.array([mj_to_gen(Qm[i]) for i in idx]).T;h=T/(N-1)
  V=np.zeros_like(G);V[:,1:]=np.diff(G,axis=1)/h;A=np.zeros_like(G);A[:,:-1]=np.diff(V,axis=1)/h
  FL=np.zeros((6,N));FL[2]=355;FR=FL.copy()
  return G,V,A,FL,FR
if __name__=='__main__':
  N=int(os.environ.get('N','41'));T=float(os.environ.get('T','0.8'))
  g=guess_from_ref('/tmp/wbswing/ref_tau0.300.npz',N,T)
  t0=time.time();op,X=build(N,T,g)
  try: sol=op.solve();st='solved'
  except Exception as e: sol=op.debug;st='FAILED '+str(e)[:200]
  vals=[np.array(sol.value(x)) for x in X];print('status',st,'time',round(time.time()-t0,1))
  np.savez(f'/tmp/wbswing/nlp_N{N}_T{T}.npz',Q=vals[0],V=vals[1],A=vals[2],FL=vals[3],FR=vals[4],N=N,T=T,status=st)
