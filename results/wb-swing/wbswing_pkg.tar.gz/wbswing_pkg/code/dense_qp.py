import numpy as np,casadi as ca,osqp,scipy.sparse as sp,json,sys
import nlp as P, cmodel as M
S=sys.argv[1] if len(sys.argv)>1 else 'sol_N81T0.8.npz'
z=np.load(S);Qs,Vs,As,Fl,Fr=z['Q'],z['V'],z['A'],z['FL'],z['FR'];T=float(z['T']);No=Qs.shape[1];ho=T/(No-1)
def path(t):
  k=min(int(round(t/ho,9)),No-1)
  if k==No-1: return Qs[:,k],Vs[:,k],As[:,k]
  s=t-k*ho;return Qs[:,k]+Vs[:,k]*s+0.5*As[:,k]*s*s,Vs[:,k]+As[:,k]*s,As[:,k]
fl=ca.SX.sym('fl',6);fr=ca.SX.sym('fr',6);q=ca.SX.sym('q',M.NQ);v=ca.SX.sym('v',M.NQ);a=ca.SX.sym('a',M.NQ);f=ca.vertcat(fl,fr)
tq,fb,nb=P.ID(q,v,a,fl,fr);out=ca.vertcat(tq,fb,nb)
Fo=ca.Function('Fo',[q,v,a],[ca.substitute(out,f,ca.DM.zeros(12)),ca.jacobian(out,f)])
mu=0.42;G=[]
for o in (0,6):
  for (i,c) in [(0,mu),(1,mu),(3,0.015),(4,0.06),(5,0.03)]:
    for sgn in (1,-1):
      row=np.zeros(12);row[o+i]=sgn;row[o+2]=-c;G.append(row)
  row=np.zeros(12);row[o+2]=-1;G.append(row)
G=np.array(G);ub=np.zeros(len(G));ub[G[:,2]+G[:,8]==-1]=-20
nj=len(P.jn);W=np.diag(1/P.eff**2)
ts=np.arange(0,T+1e-9,0.002);TAU=[];FW=[];stat=[]
for t in ts:
  qq,vv,aa=path(t);o0,J=Fo(qq,vv,aa);o0=np.array(o0).flatten();J=np.array(J)
  Jt,Jb=J[:nj],J[nj:];t0,b0=o0[:nj],o0[nj:]
  Pm=sp.csc_matrix(Jt.T@W@Jt+1e-8*np.eye(12));qv=Jt.T@W@t0
  A=sp.csc_matrix(np.vstack([Jb,G]));l=np.r_[-b0,-np.inf*np.ones(len(G))];u=np.r_[-b0,ub]
  pr=osqp.OSQP();pr.setup(Pm,qv,A,l,u,verbose=False,eps_abs=1e-9,eps_rel=1e-9,max_iter=20000,polish=True);rs=pr.solve()
  fw=rs.x;TAU.append(t0+Jt@fw);FW.append(fw);stat.append(rs.info.status)
TAU=np.array(TAU);FW=np.array(FW);r=np.abs(TAU)/P.eff
print('statuses',set(stat),'max ratio',r.max(),P.jn[r.max(0).argmax()],'bad t',ts[r.max(1)>1.0])
np.savez('/tmp/wbswing/dense_qp.npz',t=ts,tau=TAU,fw=FW)
