import numpy as np,mujoco,json,os,sys,casadi as ca
import nlp as P, cmodel as M
S=sys.argv[1] if len(sys.argv)>1 else 'sol_N81T0.8.npz'
z=np.load(S);Qs,Vs,As,Fl,Fr=z['Q'],z['V'],z['A'],z['FL'],z['FR'];T=float(z['T']);No=Qs.shape[1];ho=T/(No-1)
def path(t):
  k=min(int(t/ho),No-2);s=t-k*ho
  if t>=T: k=No-1;s=t-T;return Qs[:,k]+Vs[:,k]*s,Vs[:,k].copy(),As[:,k].copy()
  return Qs[:,k]+Vs[:,k]*s+0.5*As[:,k]*s*s,Vs[:,k]+As[:,k]*s,As[:,k]
fint=lambda F,t:np.array([np.interp(t,np.linspace(0,T,No),f) for f in F])
# jacobian of base wrench wrt foot wrench
fl=ca.SX.sym('fl',6);fr=ca.SX.sym('fr',6);q=ca.SX.sym('q',M.NQ);v=ca.SX.sym('v',M.NQ);a=ca.SX.sym('a',M.NQ)
tq,fb,nb=P.ID(q,v,a,fl,fr);Jf=ca.Function('Jf',[q,v,a,fl,fr],[ca.jacobian(ca.vertcat(fb,nb),ca.vertcat(fl,fr))])
dt=0.002;ts=np.arange(0,T+1e-9,dt);TAU=[];FW=[]
for t in ts:
  qq,vv,aa=path(t);f=np.r_[fint(Fl,t),fint(Fr,t)]
  _,b1,b2=[np.array(x).flatten() for x in P.ID(qq,vv,aa,f[:6],f[6:])];r=np.r_[b1,b2]
  J=np.array(Jf(qq,vv,aa,f[:6],f[6:]));f=f-np.linalg.pinv(J)@r
  tt=np.array(P.ID(qq,vv,aa,f[:6],f[6:])[0]).flatten();TAU.append(tt);FW.append(f)
TAU=np.array(TAU);FW=np.array(FW)
peak=np.abs(TAU).max(0);ratio=peak/P.eff
# cone check dense
cone=[]
for f in FW:
  for F in (f[:6],f[6:]): cone.append(max(abs(F[0])/F[2],abs(F[1])/F[2]))
# joint velocity peaks from path
Vd=np.array([path(t)[1][6:] for t in ts]);Qd=np.array([path(t)[0][6:] for t in ts])
res=dict(dense_dt=dt,peak_tau_ratio_max=float(ratio.max()),worst_joint=P.jn[int(ratio.argmax())],max_mu_used=float(max(cone)),min_fz=float(FW[:,[2,8]].min()),
  vel_ratio_max=float((np.abs(Vd).max(0)/P.vmx).max()),pos_margin_min=float(min((Qd-P.lo).min(),(P.hi-Qd).min())))
table=[dict(joint=P.jn[i],peak_tau=round(float(peak[i]),2),limit=float(P.eff[i]),pct=round(100*float(ratio[i]),1),
  peak_vel=round(float(np.abs(Vd[:,i]).max()),2),vel_limit=float(P.vmx[i])) for i in range(len(P.jn))]
np.savez('/tmp/wbswing/dense_tau.npz',t=ts,tau=TAU,fw=FW)
json.dump(dict(summary=res,table=table),open('/tmp/wbswing/dense_check.json','w'),indent=1)
print(json.dumps(res));print(sorted([(r['pct'],r['joint']) for r in table])[-8:])
