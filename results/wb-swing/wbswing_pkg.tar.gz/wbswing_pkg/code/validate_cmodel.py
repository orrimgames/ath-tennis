import casadi as ca,numpy as np,mujoco
import cmodel as M
m=M.m;d=mujoco.MjData(m);rng=np.random.default_rng(0)
q=ca.SX.sym('q',M.NQ);v=ca.SX.sym('v',M.NQ);a=ca.SX.sym('a',M.NQ)
sp,sR=M.site_pose(q,'racket_contact');lfp,lfR=M.site_pose(q,'left_foot')
tau,fb,nb=M.rnea(q,v,a)
Ffk=ca.Function('fk',[q],[sp,ca.reshape(sR,9,1),lfp,M.com(q)]);Fid=ca.Function('id',[q,v,a],[tau,fb,nb])
Rf=ca.Function('R',[q],[M.Rzyx(q[3:6])]);Ef=ca.Function('E',[q],[M.Emat(q[3:6])])
Edf=ca.Function('Ed',[q,v],[ca.jtimes(M.Emat(q[3:6]),q[3:6],v[3:6])])
def to_mj(qq,vv,aa):
  R=np.array(Rf(qq));quat=np.zeros(4);mujoco.mju_mat2Quat(quat,R.flatten())
  d.qpos[:3]=qq[:3];d.qpos[3:7]=quat
  E=np.array(Ef(qq));Ed=np.array(Edf(qq,vv))
  ww=E@vv[3:6];wdw=E@aa[3:6]+Ed@vv[3:6]
  d.qvel[:3]=vv[:3];d.qvel[3:6]=R.T@ww;d.qacc[:3]=aa[:3];d.qacc[3:6]=R.T@wdw
  for i,b in enumerate(M.hinge_b):
    d.qpos[M.B[b]['qadr']]=qq[6+i];d.qvel[M.B[b]['dof']]=vv[6+i];d.qacc[M.B[b]['dof']]=aa[6+i]
  return R
m.opt.disableflags|=int(mujoco.mjtDisableBit.mjDSBL_CONTACT)|int(mujoco.mjtDisableBit.mjDSBL_FRICTIONLOSS)|int(mujoco.mjtDisableBit.mjDSBL_LIMIT)
emax=dict(site=0,siteR=0,foot=0,com=0,tau=0,fb=0,nb=0)
for t in range(20):
  qq=np.r_[rng.normal(0,0.5,3),rng.normal(0,0.4,3),rng.uniform(M.m.jnt_range[[M.B[b]['jid'] for b in M.hinge_b],0],M.m.jnt_range[[M.B[b]['jid'] for b in M.hinge_b],1])]
  vv=rng.normal(0,2,M.NQ);aa=rng.normal(0,5,M.NQ)
  R=to_mj(qq,vv,aa);qacc_save=d.qacc.copy();mujoco.mj_forward(m,d);d.qacc[:]=qacc_save
  o=[np.array(x).flatten() for x in Ffk(qq)]
  emax['site']=max(emax['site'],np.abs(o[0]-d.site('racket_contact').xpos).max())
  emax['siteR']=max(emax['siteR'],np.abs(o[1].reshape(3,3,order='F')-d.site('racket_contact').xmat.reshape(3,3)).max())
  emax['foot']=max(emax['foot'],np.abs(o[2]-d.site('left_foot').xpos).max());emax['com']=max(emax['com'],np.abs(o[3]-d.subtree_com[1]).max())
  mujoco.mj_inverse(m,d);qi=d.qfrc_inverse.copy()
  tt,ff,nn=[np.array(x).flatten() for x in Fid(qq,vv,aa)]
  tj=np.array([qi[M.B[b]['dof']] for b in M.hinge_b])
  emax['tau']=max(emax['tau'],np.abs(tt-tj).max()/max(1,np.abs(tj).max()))
  emax['fb']=max(emax['fb'],np.abs(ff-qi[:3]).max()/max(1,np.abs(qi[:3]).max()))
  emax['nb']=max(emax['nb'],np.abs(R.T@nn-qi[3:6]).max()/max(1,np.abs(qi[3:6]).max()))
print({k:float('%.2e'%v) for k,v in emax.items()})
